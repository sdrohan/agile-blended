package app.test;

import static org.junit.Assert.*;
import java.util.List;
import org.apache.http.client.HttpResponseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import app.api.PacemakerAPI;
import app.api.Rest;
import app.models.User;
 
public class UserTest
{
  static User users[] = 
  { 
    new User ("homer",  "simpson", "homer@simpson.com",  "secret"),
    new User ("lisa",   "simpson", "lisa@simpson.com",   "secret"),
    new User ("maggie", "simpson", "maggie@simpson.com", "secret"),
    new User ("bart",   "simpson", "bart@simpson.com",   "secret"),
    new User ("marge",  "simpson", "marge@simpson.com",  "secret"),
 };
  
  User user;
  
  @Before
  public void setUp() throws Exception
  {
    user = new User ("mark", "simpson", "mark@simpson.com", "secret");
    PacemakerAPI.deleteUsers();
  }
  
  @After
  public void tearDown() throws Exception
  {
    PacemakerAPI.deleteUsers();
  }

  @Test
  public void createUserJson() throws Exception
  {      
    User user1 = PacemakerAPI.createUser(Fixtures.userJson);
    User user2 = PacemakerAPI.getUser(user1.id);
    assertEquals(user1, user2);
    PacemakerAPI.deleteUser(user1.id);
  }

  @Test
  public void createUserObj() throws Exception
  {      
    User user2 = PacemakerAPI.createUser(user);
    
    assertTrue(user.equals(user2));
    PacemakerAPI.deleteUser(user2.id);
  }
 
  @Test
  public void createUserObjs() throws Exception
  {    
    for (User user : Fixtures.users)
    {
      User user2 = PacemakerAPI.createUser(user);
      user.id = user2.id;
    }
    
    List <User> users = PacemakerAPI.getUsers();
    assertEquals(users.size(), Fixtures.users.length);
    
    for (User user : Fixtures.users)
    {
      PacemakerAPI.deleteUser(user.id);
    }
    List <User> users2 = PacemakerAPI.getUsers();
    assertEquals(0, users2.size());
  }

  @Test
  public void updateUser() throws Exception
  {
    User user2 = PacemakerAPI.createUser(user);
    user2.email = "NEWNAME@simpson.com";
    PacemakerAPI.updateUser(user2.id, user2);
    
    User user3 = PacemakerAPI.getUser(user2.id);
    assertEquals (user3.email, "NEWNAME@simpson.com");
    assertEquals (user3.id, user2.id);
 
    PacemakerAPI.deleteUser(user2.id);
  }
  
  @Test
  public void updateNonExistantUser() throws Exception
  {
    try
    {
      Rest.put("/api/users/4000", Fixtures.userJson);
      fail ("put error");
    }
    catch(HttpResponseException e)
    {
      assertTrue (404 == e.getStatusCode());    
    }
  }
  
  @Test
  public void deleteeNonExistantUser() throws Exception
  {
    try
    {
      Rest.delete("/api/users/4000");
      fail ("delete error");
    }
    catch(HttpResponseException e)
    {
      assertTrue (404 == e.getStatusCode());    
    }  
  }
}
