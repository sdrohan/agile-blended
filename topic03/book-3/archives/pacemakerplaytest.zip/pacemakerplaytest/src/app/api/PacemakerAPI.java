package app.api;

import java.util.List;
import app.models.User;
import static app.api.JsonParser.*;

public class PacemakerAPI
{ 
  public static List<User> getUsers () throws Exception
  {
    String response =  Rest.get("/api/users");
    List<User> userList = renderUsers(response);
    return userList;
  }
  
  public static User createUser(String userJson) throws Exception
  {
    String response = Rest.post ("/api/users", userJson);
    return renderUser(response);
  }
  
  public static User createUser(User user) throws Exception
  {
    return createUser(renderUser(user));
  }
  
  public static User getUser(Long id) throws Exception
  {
    String response = Rest.get ("/api/users/" + id);;
    User user = renderUser(response);
    return user;
  }
  
  public static void deleteUsers() throws Exception
  {
    Rest.delete("/api/users");    
  }
  public static void deleteUser(Long userId) throws Exception
  {  
   Rest.delete("/api/users/" + userId );
  }
  
  public static void updateUser(Long userId, String userJson) throws Exception
  {
    Rest.put("/api/users/" + userId, userJson);
  }
  
  public static void updateUser(Long userId, User user) throws Exception
  {
    Rest.put("/api/users/" + userId, renderUser(user));
  }
}
