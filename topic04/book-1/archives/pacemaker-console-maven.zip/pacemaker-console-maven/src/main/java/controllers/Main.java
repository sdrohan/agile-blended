package controllers;

import java.io.File;
import asg.cliche.Command;
import asg.cliche.Param;
import asg.cliche.Shell;
import asg.cliche.ShellFactory;
import models.Activity;
import models.User;
import utils.BinarySerializer;
import utils.JSONSerializer;
import utils.Serializer;
import utils.XMLSerializer;

import java.util.Collection;
import com.google.common.base.Optional;

public class Main
{
    PacemakerAPI paceApi;
    
	public Main() throws Exception
	{
		//XML serializer
		File  datastore = new File("datastore.xml");
		Serializer serializer = new XMLSerializer(datastore);
		
		//JSON serializer
	    //File  datastore = new File("datastore.json");
		//Serializer serializer = new JSONSerializer(datastore);
		
		//Binary serializer
		//File  datastore = new File("datastore.txt");
		//Serializer serializer = new BinarySerializer(datastore);

		paceApi = new PacemakerAPI(serializer);
		if (datastore.isFile())
		{
			paceApi.load();
		}
	}	

  @Command(description="Create a new User")
  public void createUser (@Param(name="first name") String firstName, @Param(name="last name") String lastName, 
                          @Param(name="email")      String email,     @Param(name="password")  String password)
  {
    paceApi.createUser(firstName, lastName, email, password);
  }

  @Command(description="Get a Users details")
  public void getUser (@Param(name="email") String email)
  {
    User user = paceApi.getUserByEmail(email);
    System.out.println(user);
  }

  @Command(description="Get all users details")
  public void getUsers ()
  {
    Collection<User> users = paceApi.getUsers();
    System.out.println(users);
  }

  @Command(description="Delete a User")
  public void deleteUser (@Param(name="email") String email)
  {
    Optional<User> user = Optional.fromNullable(paceApi.getUserByEmail(email));
    if (user.isPresent())
    {
      paceApi.deleteUser(user.get().id);
    }
  }

  @Command(description="Add an activity")
  public void addActivity (@Param(name="user id") Long userId, 
		                   @Param(name="type") String type, 
		                   @Param(name="location") String location,     
		                   @Param(name="distance") double distance)
  { 
	  Optional<User> user = Optional.fromNullable(paceApi.getUser(userId));
	  if (user.isPresent())
	  {	 
		  paceApi.createActivity(userId, type, location, distance);
	  }
  }

  
  @Command(description="Add a location")
  public void addLocation (@Param(name="activity id") Long activityId, 
		                   @Param(name="latitude") float latitude, 
		                   @Param(name="longitude") float longitude)
  {
	  Optional<Activity> activity = Optional.fromNullable(paceApi.getActivity(activityId));
	  if (activity.isPresent())
	  {
	     paceApi.addLocation(activityId, latitude, longitude);
	  }
  }
  
  
  public static void main(String[] args) throws Exception
  {
    Main main = new Main();

    Shell shell = ShellFactory.createConsoleShell("pm", "Welcome to pacemaker-console - ?help for instructions", main);
    shell.commandLoop();

    main.paceApi.store();
  }
}