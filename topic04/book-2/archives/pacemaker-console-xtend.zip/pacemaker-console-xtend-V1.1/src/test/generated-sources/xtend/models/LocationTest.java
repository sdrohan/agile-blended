package models;

import models.Location;
import org.junit.Assert;
import org.junit.Test;

@SuppressWarnings("all")
public class LocationTest {
  private final String locationStr = "23.3,44.4";
  
  private final Location location1 = new Location(23.3f, 44.4f);
  
  private final Location location2 = new Location(23.3f, 44.4f);
  
  private final Location location3 = new Location(55.5f, 66.6f);
  
  @Test
  public void testCreate() {
    float _latitude = this.location1.getLatitude();
    Assert.assertEquals(0.001, 23.3f, _latitude);
    float _longitude = this.location1.getLongitude();
    Assert.assertEquals(0.001, 44.4f, _longitude);
  }
  
  @Test
  public void testEquals() {
    Assert.assertEquals(this.location1, this.location2);
    Assert.assertNotEquals(this.location1, this.location3);
  }
  
  @Test
  public void testToString() {
    String _string = this.location1.toString();
    Assert.assertEquals(this.locationStr, _string);
  }
}
