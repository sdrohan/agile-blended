package models;

import java.util.List;
import models.Activity;
import models.Location;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.junit.Assert;
import org.junit.Test;

@SuppressWarnings("all")
public class ActivityTest {
  private final String activityStr = "Activity [\n  _id = 0\n  _type = \"walk\"\n  _location = \"fridge\"\n  _distance = 0.001\n  _starttime = 2013-05-12T09:30:00.000+01:00\n  _duration = PT500S\n  _route = ArrayList ()\n]";
  
  private final Activity activity = new Activity(Long.valueOf(0l), "walk", "fridge", 0.001, new DateTime(2013, 5, 12, 9, 30), new Duration(500000));
  
  @Test
  public void testCreate() {
    String _type = this.activity.getType();
    Assert.assertEquals("walk", _type);
    String _location = this.activity.getLocation();
    Assert.assertEquals("fridge", _location);
    double _distance = this.activity.getDistance();
    Assert.assertEquals(0.0001, 0.001, _distance);
  }
  
  @Test
  public void testToString() {
    String _string = this.activity.toString();
    Assert.assertEquals(this.activityStr, _string);
  }
  
  @Test
  public void testRoute() {
    DateTime _dateTime = new DateTime(2013, 5, 12, 9, 30);
    Duration _duration = new Duration(10000);
    final Activity activity1 = new Activity(Long.valueOf(0l), "walk", "work", 1.1, _dateTime, _duration);
    List<Location> _route = activity1.getRoute();
    Location _location = new Location(23.3f, 33.3f);
    _route.add(_location);
    List<Location> _route_1 = activity1.getRoute();
    Location _location_1 = new Location(23.4f, 34.4f);
    _route_1.add(_location_1);
    List<Location> _route_2 = activity1.getRoute();
    Location _location_2 = new Location(23.5f, 35.5f);
    _route_2.add(_location_2);
    DateTime _dateTime_1 = new DateTime(2013, 5, 12, 9, 30);
    Duration _duration_1 = new Duration(10000);
    final Activity activity2 = new Activity(Long.valueOf(0l), "walk", "work", 1.1, _dateTime_1, _duration_1);
    List<Location> _route_3 = activity2.getRoute();
    Location _location_3 = new Location(23.3f, 33.3f);
    _route_3.add(_location_3);
    List<Location> _route_4 = activity2.getRoute();
    Location _location_4 = new Location(23.4f, 34.4f);
    _route_4.add(_location_4);
    List<Location> _route_5 = activity2.getRoute();
    Location _location_5 = new Location(23.5f, 35.5f);
    _route_5.add(_location_5);
    DateTime _dateTime_2 = new DateTime(2013, 5, 14, 10, 45);
    Duration _duration_2 = new Duration(50000);
    final Activity activity3 = new Activity(Long.valueOf(0l), "walk", "work", 1.1, _dateTime_2, _duration_2);
    List<Location> _route_6 = activity3.getRoute();
    Location _location_6 = new Location(23.3f, 33.3f);
    _route_6.add(_location_6);
    List<Location> _route_7 = activity3.getRoute();
    Location _location_7 = new Location(43.4f, 54.4f);
    _route_7.add(_location_7);
    List<Location> _route_8 = activity3.getRoute();
    Location _location_8 = new Location(53.5f, 35.5f);
    _route_8.add(_location_8);
    Assert.assertEquals(activity1, activity2);
    Assert.assertNotEquals(activity1, activity3);
  }
}
