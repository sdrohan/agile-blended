package controllers;

import controllers.PacemakerAPI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import models.Activity;
import models.Fixtures;
import models.Location;
import models.User;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("all")
public class PacemakerAPITest {
  private PacemakerAPI pacemaker;
  
  private User homer;
  
  @Before
  public void setup() {
    PacemakerAPI _pacemakerAPI = new PacemakerAPI();
    this.pacemaker = _pacemakerAPI;
    final Consumer<User> _function = new Consumer<User>() {
      public void accept(final User it) {
        String _firstname = it.getFirstname();
        String _lastname = it.getLastname();
        String _email = it.getEmail();
        String _password = it.getPassword();
        PacemakerAPITest.this.pacemaker.createUser(_firstname, _lastname, _email, _password);
      }
    };
    Fixtures.users.forEach(_function);
    User _user = new User(Long.valueOf(5l), "homer", "simpson", "homer@simpson.com", "secret");
    this.homer = _user;
  }
  
  @After
  public void tearDown() {
    this.pacemaker = null;
    this.homer = null;
  }
  
  @Test
  public void testUser() {
    int _size = Fixtures.users.size();
    Collection<User> _users = this.pacemaker.getUsers();
    int _size_1 = _users.size();
    Assert.assertEquals(_size, _size_1);
    final Long id = this.pacemaker.createUser("homer", "simpson", "homer@simpson.com", "secret");
    int _size_2 = Fixtures.users.size();
    int _plus = (_size_2 + 1);
    Collection<User> _users_1 = this.pacemaker.getUsers();
    int _size_3 = _users_1.size();
    Assert.assertEquals(_plus, _size_3);
    User _user = this.pacemaker.getUser(id);
    Assert.assertEquals(this.homer, _user);
  }
  
  @Test
  public void testUsers() {
    int _size = Fixtures.users.size();
    Collection<User> _users = this.pacemaker.getUsers();
    int _size_1 = _users.size();
    Assert.assertEquals(_size, _size_1);
    int _size_2 = Fixtures.users.size();
    Collection<User> _users_1 = this.pacemaker.getUsers();
    int _size_3 = _users_1.size();
    Assert.assertEquals(_size_2, _size_3);
    final Consumer<User> _function = new Consumer<User>() {
      public void accept(final User it) {
        String _email = it.getEmail();
        final User eachUser = PacemakerAPITest.this.pacemaker.getUser(_email);
        Assert.assertEquals(it, eachUser);
        Assert.assertNotSame(it, eachUser);
      }
    };
    Fixtures.users.forEach(_function);
  }
  
  @Test
  public void testDeleteUsers() {
    int _length = ((Object[])Conversions.unwrapArray(Fixtures.users, Object.class)).length;
    Collection<User> _users = this.pacemaker.getUsers();
    int _size = _users.size();
    Assert.assertEquals(_length, _size);
    final User user = this.pacemaker.getUser("marge@simpson.com");
    Long _id = user.getId();
    this.pacemaker.deleteUser(_id);
    int _length_1 = ((Object[])Conversions.unwrapArray(Fixtures.users, Object.class)).length;
    int _minus = (_length_1 - 1);
    Collection<User> _users_1 = this.pacemaker.getUsers();
    int _size_1 = _users_1.size();
    Assert.assertEquals(_minus, _size_1);
  }
  
  @Test
  public void testAddActivity() {
    User _user = this.pacemaker.getUser("marge@simpson.com");
    Long _id = _user.getId();
    final Activity activity = this.pacemaker.createActivity(_id, "run", "springfield", 5, "11:2:2012 9:00:00", "20:00:00");
    Long _id_1 = activity.getId();
    final Activity returnedActivity = this.pacemaker.getActivity(_id_1);
    Assert.assertEquals(activity, returnedActivity);
  }
  
  @Test
  public void testAddActivityWithSingleLocation() {
    User _user = this.pacemaker.getUser("marge@simpson.com");
    Long _id = _user.getId();
    final Activity activity = this.pacemaker.createActivity(_id, "run", "springfield", 5, "11:2:2012 9:00:00", "20:00:00");
    final Location location = new Location(23.3f, 33.3f);
    Long _id_1 = activity.getId();
    final Activity returnedActivity = this.pacemaker.getActivity(_id_1);
    Long _id_2 = returnedActivity.getId();
    float _latitude = location.getLatitude();
    float _longitude = location.getLongitude();
    this.pacemaker.addLocation(_id_2, _latitude, _longitude);
    Long _id_3 = returnedActivity.getId();
    final Activity otherActivity = this.pacemaker.getActivity(_id_3);
    List<Location> _route = otherActivity.getRoute();
    int _size = _route.size();
    Assert.assertEquals(1, _size);
    float _latitude_1 = location.getLatitude();
    List<Location> _route_1 = otherActivity.getRoute();
    Location _get = _route_1.get(0);
    float _latitude_2 = _get.getLatitude();
    Assert.assertEquals(0.0001, _latitude_1, _latitude_2);
    float _longitude_1 = location.getLongitude();
    List<Location> _route_2 = otherActivity.getRoute();
    Location _get_1 = _route_2.get(0);
    float _longitude_2 = _get_1.getLongitude();
    Assert.assertEquals(0.0001, _longitude_1, _longitude_2);
  }
  
  @Test
  public void testAddActivityWithMultipleLocation() {
    Location _location = new Location(23.3f, 33.3f);
    Location _location_1 = new Location(34.4f, 45.2f);
    Location _location_2 = new Location(25.3f, 34.3f);
    Location _location_3 = new Location(44.4f, 23.3f);
    final ArrayList<Location> locations = CollectionLiterals.<Location>newArrayList(_location, _location_1, _location_2, _location_3);
    User _user = this.pacemaker.getUser("marge@simpson.com");
    Long _id = _user.getId();
    final Activity activity = this.pacemaker.createActivity(_id, "run", "springfield", 5, "11:2:2012 9:00:00", "20:00:00");
    Long _id_1 = activity.getId();
    final Activity returnedActivity = this.pacemaker.getActivity(_id_1);
    final Consumer<Location> _function = new Consumer<Location>() {
      public void accept(final Location it) {
        Long _id = returnedActivity.getId();
        float _latitude = it.getLatitude();
        float _longitude = it.getLongitude();
        PacemakerAPITest.this.pacemaker.addLocation(_id, _latitude, _longitude);
      }
    };
    locations.forEach(_function);
    Long _id_2 = returnedActivity.getId();
    final Activity otherActivity = this.pacemaker.getActivity(_id_2);
    int _size = locations.size();
    List<Location> _route = otherActivity.getRoute();
    int _size_1 = _route.size();
    Assert.assertEquals(_size, _size_1);
    List<Location> _route_1 = otherActivity.getRoute();
    Assert.assertEquals(locations, _route_1);
  }
}
