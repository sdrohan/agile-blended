package models;

import org.eclipse.xtend.lib.Data;
import org.eclipse.xtext.xbase.lib.Pure;

@Data
@SuppressWarnings("all")
public class Location {
  private final float _latitude;
  
  private final float _longitude;
  
  @Override
  public String toString() {
    float _latitude = this.getLatitude();
    String _plus = (Float.valueOf(_latitude) + ",");
    float _longitude = this.getLongitude();
    return (_plus + Float.valueOf(_longitude));
  }
  
  public Location(final float latitude, final float longitude) {
    super();
    this._latitude = latitude;
    this._longitude = longitude;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + Float.floatToIntBits(this._latitude);
    result = prime * result + Float.floatToIntBits(this._longitude);
    return result;
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Location other = (Location) obj;
    if (Float.floatToIntBits(other._latitude) != Float.floatToIntBits(this._latitude))
      return false; 
    if (Float.floatToIntBits(other._longitude) != Float.floatToIntBits(this._longitude))
      return false; 
    return true;
  }
  
  @Pure
  public float getLatitude() {
    return this._latitude;
  }
  
  @Pure
  public float getLongitude() {
    return this._longitude;
  }
}
