package parsers;

import com.bethecoder.ascii_table.ASCIITable;
import com.bethecoder.ascii_table.impl.CollectionASCIITableAware;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import models.Activity;
import models.User;
import parsers.Parser;

@SuppressWarnings("all")
public class AsciiParser extends Parser {
  @Override
  public String renderUser(final User user) {
    String _xblockexpression = null;
    {
      final List<User> userList = new ArrayList<User>();
      userList.add(user);
      _xblockexpression = this.renderUsers(userList);
    }
    return _xblockexpression;
  }
  
  @Override
  public String renderActivities(final Collection<Activity> activities) {
    String _xifexpression = null;
    boolean _isEmpty = activities.isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      String _xblockexpression = null;
      {
        final List<Activity> activityList = new ArrayList<Activity>(activities);
        CollectionASCIITableAware<Activity> activitiesTable = new CollectionASCIITableAware<Activity>(activityList, "id", "type", "location", "distance", "starttime", "duration", "route");
        ASCIITable _instance = ASCIITable.getInstance();
        _xblockexpression = _instance.getTable(activitiesTable);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
  
  @Override
  public String renderUsers(final Collection<User> users) {
    String _xifexpression = null;
    boolean _isEmpty = users.isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      String _xblockexpression = null;
      {
        final List<User> userList = new ArrayList<User>(users);
        CollectionASCIITableAware<User> asciiTableAware = new CollectionASCIITableAware<User>(userList, "id", "firstname", "lastname", "email", "password");
        ASCIITable _instance = ASCIITable.getInstance();
        _xblockexpression = _instance.getTable(asciiTableAware);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
}
