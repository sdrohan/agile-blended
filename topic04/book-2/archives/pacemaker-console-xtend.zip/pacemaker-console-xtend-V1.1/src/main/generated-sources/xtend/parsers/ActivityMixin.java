package parsers;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("all")
public interface ActivityMixin {
  /**
   * This interface is part of our custom written JSON serialiser.
   * 
   * Mix-in annotations are annotations defined in an interface (the mix-in).
   * They are used to augment annotations of the target class. Augmenting means that annotations of the
   * mix-in interface are used as if they were directly included in target class.
   * http://www.cowtowncoder.com/blog/archives/2009/08/entry_305.html
   * 
   * @JsonIgnore indicates that the annotated method is to be ignored by serialization / deserialization
   */
  @JsonIgnore
  public abstract Long getId();
}
