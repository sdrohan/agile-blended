package utils;

import com.google.common.base.Objects;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import org.eclipse.xtext.xbase.lib.Exceptions;
import utils.Serializer;

@SuppressWarnings("all")
public class JSONSerializer implements Serializer {
  private Deque<Object> stack = new ArrayDeque<Object>();
  
  private final File file;
  
  public JSONSerializer(final String filename) {
    File _file = new File((filename + ".json"));
    this.file = _file;
  }
  
  @Override
  public void push(final Object o) {
    this.stack.push(o);
  }
  
  @Override
  public Object pop() {
    return this.stack.pop();
  }
  
  @SuppressWarnings("unchecked")
  @Override
  public void read() {
    try {
      ObjectInputStream is = null;
      try {
        JettisonMappedXmlDriver _jettisonMappedXmlDriver = new JettisonMappedXmlDriver();
        final XStream xstream = new XStream(_jettisonMappedXmlDriver);
        FileReader _fileReader = new FileReader(this.file);
        ObjectInputStream _createObjectInputStream = xstream.createObjectInputStream(_fileReader);
        is = _createObjectInputStream;
        Object _readObject = is.readObject();
        this.stack = ((Deque<Object>) _readObject);
      } finally {
        boolean _notEquals = (!Objects.equal(is, null));
        if (_notEquals) {
          is.close();
        }
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public void write() {
    try {
      ObjectOutputStream os = null;
      try {
        JettisonMappedXmlDriver _jettisonMappedXmlDriver = new JettisonMappedXmlDriver();
        final XStream xstream = new XStream(_jettisonMappedXmlDriver);
        FileWriter _fileWriter = new FileWriter(this.file);
        ObjectOutputStream _createObjectOutputStream = xstream.createObjectOutputStream(_fileWriter);
        os = _createObjectOutputStream;
        os.writeObject(this.stack);
      } finally {
        boolean _notEquals = (!Objects.equal(os, null));
        if (_notEquals) {
          os.close();
        }
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
