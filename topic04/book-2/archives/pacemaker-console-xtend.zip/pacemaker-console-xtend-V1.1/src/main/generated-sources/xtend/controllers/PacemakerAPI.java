package controllers;

import com.google.common.base.Optional;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import models.Activity;
import models.Location;
import models.User;
import org.eclipse.xtend.lib.annotations.Accessors;
import org.eclipse.xtext.xbase.lib.Pure;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import utils.DateTimeFormatters;
import utils.Serializer;

@SuppressWarnings("all")
public class PacemakerAPI {
  private static long userIndex = 0;
  
  private static long activityIndex = 0;
  
  private Map<Long, User> userMap = new HashMap<Long, User>();
  
  private Map<String, User> userEmailMap = new HashMap<String, User>();
  
  private Map<Long, Activity> activityMap = new HashMap<Long, Activity>();
  
  @Accessors
  private Collection<User> users = this.userMap.values();
  
  @Accessors
  private Serializer serializer;
  
  public PacemakerAPI() {
    PacemakerAPI.userIndex = 0;
    PacemakerAPI.activityIndex = 0;
  }
  
  public void load() throws Exception {
    this.serializer.read();
    Object _pop = this.serializer.pop();
    PacemakerAPI.activityIndex = (((Long) _pop)).longValue();
    Object _pop_1 = this.serializer.pop();
    PacemakerAPI.userIndex = (((Long) _pop_1)).longValue();
    Object _pop_2 = this.serializer.pop();
    this.activityMap = ((Map<Long, Activity>) _pop_2);
    Object _pop_3 = this.serializer.pop();
    this.userEmailMap = ((Map<String, User>) _pop_3);
    Object _pop_4 = this.serializer.pop();
    this.userMap = ((Map<Long, User>) _pop_4);
    Collection<User> _values = this.userMap.values();
    this.users = _values;
  }
  
  public void store() {
    this.serializer.push(this.userMap);
    this.serializer.push(this.userEmailMap);
    this.serializer.push(this.activityMap);
    this.serializer.push(Long.valueOf(PacemakerAPI.userIndex));
    this.serializer.push(Long.valueOf(PacemakerAPI.activityIndex));
    this.serializer.write();
  }
  
  public Long createUser(final String firstName, final String lastName, final String email, final String password) {
    long _xblockexpression = (long) 0;
    {
      PacemakerAPI.userIndex = (PacemakerAPI.userIndex + 1);
      User user = new User(Long.valueOf(PacemakerAPI.userIndex), firstName, lastName, email, password);
      this.userMap.put(Long.valueOf(PacemakerAPI.userIndex), user);
      String _email = user.getEmail();
      this.userEmailMap.put(_email, user);
      _xblockexpression = PacemakerAPI.userIndex;
    }
    return Long.valueOf(_xblockexpression);
  }
  
  public User getUser(final Long id) {
    return this.userMap.get(id);
  }
  
  public User getUser(final String email) {
    return this.userEmailMap.get(email);
  }
  
  public User deleteUser(final Long id) {
    User _xblockexpression = null;
    {
      User _get = this.userMap.get(id);
      this.userEmailMap.remove(_get);
      _xblockexpression = this.userMap.remove(id);
    }
    return _xblockexpression;
  }
  
  public User deleteUser(final String email) {
    User _xblockexpression = null;
    {
      User _user = this.getUser(email);
      final User user = this.userEmailMap.remove(_user);
      Long _id = user.getId();
      _xblockexpression = this.userMap.remove(_id);
    }
    return _xblockexpression;
  }
  
  public Activity createActivity(final Long id, final String type, final String location, final double distance, final String dateStr, final String durationStr) {
    Activity activity = null;
    User _get = this.userMap.get(id);
    Optional<User> user = Optional.<User>fromNullable(_get);
    boolean _isPresent = user.isPresent();
    if (_isPresent) {
      PacemakerAPI.activityIndex = (PacemakerAPI.activityIndex + 1);
      DateTime _parseDateTime = DateTimeFormatters.parseDateTime(dateStr);
      Duration _parseDuration = DateTimeFormatters.parseDuration(durationStr);
      Activity _activity = new Activity(Long.valueOf(PacemakerAPI.activityIndex), type, location, distance, _parseDateTime, _parseDuration);
      activity = _activity;
      User _get_1 = user.get();
      Map<Long, Activity> _activities = _get_1.getActivities();
      Long _id = activity.getId();
      _activities.put(_id, activity);
      Long _id_1 = activity.getId();
      this.activityMap.put(_id_1, activity);
    }
    return activity;
  }
  
  public Activity getActivity(final Long id) {
    return this.activityMap.get(id);
  }
  
  public void addLocation(final Long id, final float latitude, final float longitude) {
    Activity _get = this.activityMap.get(id);
    final Optional<Activity> activity = Optional.<Activity>fromNullable(_get);
    boolean _isPresent = activity.isPresent();
    if (_isPresent) {
      Activity _get_1 = activity.get();
      List<Location> _route = _get_1.getRoute();
      Location _location = new Location(latitude, longitude);
      _route.add(_location);
    }
  }
  
  @Pure
  public Collection<User> getUsers() {
    return this.users;
  }
  
  public void setUsers(final Collection<User> users) {
    this.users = users;
  }
  
  @Pure
  public Serializer getSerializer() {
    return this.serializer;
  }
  
  public void setSerializer(final Serializer serializer) {
    this.serializer = serializer;
  }
}
