package models;

import java.util.HashMap;
import java.util.Map;
import models.Activity;
import org.eclipse.xtend.lib.Data;
import org.eclipse.xtend.lib.Property;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringHelper;

@Data
@SuppressWarnings("all")
public class User {
  private final Long _id;
  
  private final String _firstname;
  
  private final String _lastname;
  
  private final String _email;
  
  private final String _password;
  
  @Property
  private final Map<Long, Activity> __activities = new HashMap<Long, Activity>();
  
  public User(final Long id, final String firstname, final String lastname, final String email, final String password) {
    super();
    this._id = id;
    this._firstname = firstname;
    this._lastname = lastname;
    this._email = email;
    this._password = password;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this._id== null) ? 0 : this._id.hashCode());
    result = prime * result + ((this._firstname== null) ? 0 : this._firstname.hashCode());
    result = prime * result + ((this._lastname== null) ? 0 : this._lastname.hashCode());
    result = prime * result + ((this._email== null) ? 0 : this._email.hashCode());
    result = prime * result + ((this._password== null) ? 0 : this._password.hashCode());
    result = prime * result + ((this.__activities== null) ? 0 : this.__activities.hashCode());
    return result;
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    User other = (User) obj;
    if (this._id == null) {
      if (other._id != null)
        return false;
    } else if (!this._id.equals(other._id))
      return false;
    if (this._firstname == null) {
      if (other._firstname != null)
        return false;
    } else if (!this._firstname.equals(other._firstname))
      return false;
    if (this._lastname == null) {
      if (other._lastname != null)
        return false;
    } else if (!this._lastname.equals(other._lastname))
      return false;
    if (this._email == null) {
      if (other._email != null)
        return false;
    } else if (!this._email.equals(other._email))
      return false;
    if (this._password == null) {
      if (other._password != null)
        return false;
    } else if (!this._password.equals(other._password))
      return false;
    if (this.__activities == null) {
      if (other.__activities != null)
        return false;
    } else if (!this.__activities.equals(other.__activities))
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    String result = new ToStringHelper().toString(this);
    return result;
  }
  
  @Pure
  public Long getId() {
    return this._id;
  }
  
  @Pure
  public String getFirstname() {
    return this._firstname;
  }
  
  @Pure
  public String getLastname() {
    return this._lastname;
  }
  
  @Pure
  public String getEmail() {
    return this._email;
  }
  
  @Pure
  public String getPassword() {
    return this._password;
  }
  
  @Pure
  public Map<Long, Activity> getActivities() {
    return this.__activities;
  }
  
  @Pure
  public Map<Long, Activity> get_activities() {
    return this.__activities;
  }
}
