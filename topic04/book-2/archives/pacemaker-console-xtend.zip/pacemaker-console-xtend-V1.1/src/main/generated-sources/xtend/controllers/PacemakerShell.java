package controllers;

import asg.cliche.Command;
import asg.cliche.Param;
import asg.cliche.Shell;
import asg.cliche.ShellFactory;
import com.google.common.base.Objects;
import controllers.Ok;
import controllers.PacemakerAPI;
import controllers.PacemakerService;
import controllers.Response;
import java.util.Collections;
import java.util.Set;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import parsers.AsciiParser;
import parsers.Parser;
import utils.JSONSerializer;
import utils.XMLSerializer;

/**
 * This class kicks off the shell and defines the commands.
 * When a particular command is invoked, the relevant method in either the PacemakerAPI or PacemakerService is called.
 * This class also initialises:
 *       the console parser as the AsciiParser
 *       the serialiser as the XMLSerialiser
 */
@SuppressWarnings("all")
public class PacemakerShell {
  private PacemakerAPI paceApi;
  
  private PacemakerService pacemaker;
  
  private final String datastore = "testdatastore";
  
  private final XMLSerializer xmlSerializer = new XMLSerializer(this.datastore);
  
  private final JSONSerializer jsonSerializer = new JSONSerializer(this.datastore);
  
  public PacemakerShell() {
    PacemakerAPI _pacemakerAPI = new PacemakerAPI();
    this.paceApi = _pacemakerAPI;
    this.paceApi.setSerializer(this.xmlSerializer);
    AsciiParser _asciiParser = new AsciiParser();
    PacemakerService _pacemakerService = new PacemakerService(this.paceApi, ((Parser) _asciiParser));
    this.pacemaker = _pacemakerService;
  }
  
  @Command(description = "List all users details")
  public void listUsers() {
    Ok _users = this.pacemaker.getUsers();
    InputOutput.<Ok>println(_users);
  }
  
  @Command(description = "Create a new User")
  public void createUser(@Param(name = "first name") final String firstname, @Param(name = "last name") final String lastname, @Param(name = "email") final String email, @Param(name = "password") final String password) {
    Ok _createUser = this.pacemaker.createUser(firstname, lastname, email, password);
    InputOutput.<Ok>println(_createUser);
  }
  
  @Command(description = "List a users details")
  public void listUser(@Param(name = "email") final String email) {
    Response _user = this.pacemaker.getUser(email);
    InputOutput.<Response>println(_user);
  }
  
  @Command(description = "List a users details")
  public void listUser(@Param(name = "id") final Long id) {
    Response _user = this.pacemaker.getUser(id);
    InputOutput.<Response>println(_user);
  }
  
  @Command(description = "List a users activities")
  public void listActivities(@Param(name = "user id") final Long id) {
    Response _activities = this.pacemaker.getActivities(id);
    InputOutput.<Response>println(_activities);
  }
  
  @Command(description = "Delete a User")
  public void deleteUser(@Param(name = "id") final Long id) {
    Response _deleteUser = this.pacemaker.deleteUser(id);
    InputOutput.<Response>println(_deleteUser);
  }
  
  @Command(description = "Add an activity")
  public void addActivity(@Param(name = "user-id") final Long id, @Param(name = "type") final String type, @Param(name = "location") final String location, @Param(name = "distance") final double distance, @Param(name = "datetime") final String dateStr, @Param(name = "duration") final String durationStr) {
    try {
      Response _createActivity = this.pacemaker.createActivity(id, type, location, distance, dateStr, durationStr);
      InputOutput.<Response>println(_createActivity);
    } catch (final Throwable _t) {
      if (_t instanceof IllegalArgumentException) {
        final IllegalArgumentException e = (IllegalArgumentException)_t;
        String _message = e.getMessage();
        String _plus = ("Date or Duration format error: " + _message);
        InputOutput.<String>println(_plus);
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  @Command(description = "Add Location to an activity")
  public void addLocation(@Param(name = "activity-id") final Long id, @Param(name = "latitude") final float latitude, @Param(name = "longitude") final float longitude) {
    Response _addLocation = this.pacemaker.addLocation(id, latitude, longitude);
    InputOutput.<Response>println(_addLocation);
  }
  
  @Command(description = "List Activities")
  public void listActivities(@Param(name = "userid") final Long id, @Param(name = "sortBy: type, location, distance, date, duration") final String sortBy) {
    final Set<String> options = Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet("type", "location", "distance", "date", "duration"));
    boolean _contains = options.contains(sortBy);
    if (_contains) {
      Ok _listActivities = this.pacemaker.listActivities(id, sortBy);
      InputOutput.<Ok>println(_listActivities);
    } else {
      String _string = options.toString();
      String _plus = ("usage : la " + _string);
      InputOutput.<String>println(_plus);
    }
  }
  
  @Command(description = "Set file format")
  public void changeFileFormat(@Param(name = "file format: xml, json") final String fileFormat) {
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(fileFormat, "xml")) {
        _matched=true;
        this.paceApi.setSerializer(this.xmlSerializer);
      }
    }
    if (!_matched) {
      if (Objects.equal(fileFormat, "json")) {
        _matched=true;
        this.paceApi.setSerializer(this.jsonSerializer);
      }
    }
  }
  
  @Command(description = "Load activities persistent store")
  public void load() {
    try {
      this.paceApi.load();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Command(description = "Store activities persistent store")
  public void store() {
    this.paceApi.store();
  }
  
  public static void main(final String[] args) throws Exception {
    final PacemakerShell main = new PacemakerShell();
    final Shell shell = ShellFactory.createConsoleShell("pm", "Welcome to pacemaker-console - ?help for instructions", main);
    shell.commandLoop();
    main.paceApi.store();
  }
}
