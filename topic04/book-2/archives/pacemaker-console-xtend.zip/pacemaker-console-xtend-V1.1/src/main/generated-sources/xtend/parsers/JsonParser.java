package parsers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import java.util.Collection;
import models.Activity;
import models.User;
import org.eclipse.xtext.xbase.lib.Exceptions;
import parsers.ActivityMixin;
import parsers.Parser;
import parsers.UserMixin;

@SuppressWarnings("all")
public class JsonParser extends Parser {
  private final ObjectMapper mapper = new ObjectMapper();
  
  public JsonParser() {
    this.mapper.addMixInAnnotations(User.class, UserMixin.class);
    this.mapper.addMixInAnnotations(Activity.class, ActivityMixin.class);
  }
  
  @Override
  public String renderUser(final User user) {
    try {
      ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
      return _writerWithDefaultPrettyPrinter.writeValueAsString(user);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public String renderActivities(final Collection<Activity> activities) {
    try {
      String _xifexpression = null;
      int _size = activities.size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
        _xifexpression = _writerWithDefaultPrettyPrinter.writeValueAsString(activities);
      }
      return _xifexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public String renderUsers(final Collection<User> users) {
    try {
      ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
      return _writerWithDefaultPrettyPrinter.writeValueAsString(users);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
